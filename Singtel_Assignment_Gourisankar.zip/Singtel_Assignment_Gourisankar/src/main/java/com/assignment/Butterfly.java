package com.assignment;

public class Butterfly extends Animal {
	public String fly() {
		 return "I am flying";
	}
}
