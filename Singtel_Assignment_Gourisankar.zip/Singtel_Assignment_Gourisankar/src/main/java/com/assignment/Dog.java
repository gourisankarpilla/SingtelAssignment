package com.assignment;

public class Dog extends Animal implements Says {
	public String says() {
		return "Woof, woof";
    }
}
