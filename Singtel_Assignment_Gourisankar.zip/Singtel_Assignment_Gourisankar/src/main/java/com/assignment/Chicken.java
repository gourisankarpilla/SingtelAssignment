package com.assignment;

public class Chicken extends Bird {
	public String says() {
		 return "Cluck, cluck";
	}
	
	public String fly() {
		return "I cannot fly";
    }
}
