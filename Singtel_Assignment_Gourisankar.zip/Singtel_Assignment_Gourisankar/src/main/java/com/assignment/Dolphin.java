package com.assignment;

public class Dolphin extends Animal implements Swimmers {
	public String swim() {
		return "I am swimming";
    }
}
