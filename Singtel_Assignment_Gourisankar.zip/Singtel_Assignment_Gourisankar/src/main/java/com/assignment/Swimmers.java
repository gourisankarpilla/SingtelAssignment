package com.assignment;

public interface Swimmers {
	String swim();
}
