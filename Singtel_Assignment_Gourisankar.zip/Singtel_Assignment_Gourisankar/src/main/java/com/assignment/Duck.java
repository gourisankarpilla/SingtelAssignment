package com.assignment;

public class Duck extends Bird {
	public String says() {
		 return "Quack, quack";
	}
	
	public String swim() {
		return "I am swimming";
    }
}
