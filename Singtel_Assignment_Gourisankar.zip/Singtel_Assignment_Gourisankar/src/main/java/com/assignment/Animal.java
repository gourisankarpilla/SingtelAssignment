package com.assignment;

public class Animal {
	String walk(){
		 return "I am walking";
	}
	
	String fly(){
		 return "I am flying";
	}
	
	String says(){
		 return "I am singing";
	}
	
	String swim(){
		 return "I am swimming";
	}
}
