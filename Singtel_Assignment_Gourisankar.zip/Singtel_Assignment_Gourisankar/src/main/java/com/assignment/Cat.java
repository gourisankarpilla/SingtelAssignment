package com.assignment;

public class Cat extends Animal implements Says {
	public String says() {
		return "Meow";
    }
}
