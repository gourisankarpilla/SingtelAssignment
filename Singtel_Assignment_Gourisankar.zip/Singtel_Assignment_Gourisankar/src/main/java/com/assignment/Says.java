package com.assignment;

public interface Says {
	String says();
}
