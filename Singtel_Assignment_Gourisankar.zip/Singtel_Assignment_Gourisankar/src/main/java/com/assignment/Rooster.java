package com.assignment;

public class Rooster extends Chicken implements Says {
	public String says() {
		 return "Cock-a-doodle-doo";
	}
}
